DISCs are Jinja template to generate songs

or Definition of Implementable Songs Code
