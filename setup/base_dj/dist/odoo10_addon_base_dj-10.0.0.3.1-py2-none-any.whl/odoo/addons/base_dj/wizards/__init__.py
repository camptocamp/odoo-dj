from . import burn_selected_wiz
from . import load_compilation
